import React, { Component } from 'react'

export default class Logo extends Component {
  render() {
    return <div className="logo">ORGANIC WORLD</div>
  }
}
// <img src="/logo.jpg" alt="Logo" />
